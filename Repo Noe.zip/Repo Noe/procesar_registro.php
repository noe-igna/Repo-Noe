<?php
// Verificar si se han enviado datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recuperar datos del formulario
    $id_casa = $_POST["id_casa"];
    $direccion = $_POST["direccion"];
    $num_habitaciones = $_POST["num_habitaciones"];
    $tipo_casa = $_POST["tipo_casa"];
    $precio_renta = $_POST["precio_renta"];

    // Conectar a la base de datos (Modificar según tus credenciales)
    $conexion = new mysqli("localhost", "usuario", "contrasena", "nombre_basedatos");

    // Verificar la conexión
    if ($conexion->connect_error) {
        die("Error de conexión a la base de datos: " . $conexion->connect_error);
    }

    // Crear la tabla si no existe
    $sql_creacion_tabla = "CREATE TABLE IF NOT EXISTS casas (
                            id INT PRIMARY KEY,
                            direccion VARCHAR(255) NOT NULL,
                            num_habitaciones INT NOT NULL,
                            tipo_casa VARCHAR(50) NOT NULL,
                            precio_renta INT NOT NULL
                        )";
    $conexion->query($sql_creacion_tabla);

    // Insertar datos en la tabla
    $sql_insercion = "INSERT INTO casas (id, direccion, num_habitaciones, tipo_casa, precio_renta)
                      VALUES ('$id_casa', '$direccion', '$num_habitaciones', '$tipo_casa', '$precio_renta')";
    if ($conexion->query($sql_insercion) === TRUE) {
        echo "Registro exitoso.";
    } else {
        echo "Error en el registro: " . $conexion->error;
    }

    // Cerrar la conexión
    $conexion->close();
}
?>
