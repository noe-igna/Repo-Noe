// No tengo SQL o MYSQL se me estropiaron para untrabajo y los borre y no pense que lo bolberia a usar pero lo que me acuerdo aqui esta 


CREATE DATABASE IF NOT EXISTS registro_casas;
USE registro_casas;

CREATE TABLE IF NOT EXISTS casas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    direccion VARCHAR(255) NOT NULL,
    habitaciones INT NOT NULL,
    banos INT NOT NULL,
    metros_cuadrados INT NOT NULL,
    estado ENUM('Disponible', 'Ocupada') NOT NULL
);
//-------------------------------------------------------------------------------------

